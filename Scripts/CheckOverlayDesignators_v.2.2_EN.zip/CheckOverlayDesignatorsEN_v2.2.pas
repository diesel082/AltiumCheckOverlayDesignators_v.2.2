{==============================================================================}
{ File: CheckOverlayDesignatorsEN_v2.2.pas                                     }
{ Description: Silkscreen text designator placement error check                }
{              on Top and Bottom Overlay layers in Altium Designer (EN UI).    }
{==============================================================================}

function NormalizeAngle(AAngle: Double): Integer;
var
    Ang: Integer;
begin
    // Приведение угла к диапазону 0..360 и к ближайшему кратному 90
    Ang := Round(AAngle) mod 360;
    if Ang < 0 then
        Ang := Ang + 360;

    // 0 и 360 считаются одним и тем же положением (приводим 360 к 0)
    if Ang = 360 then
        Ang := 0;

    // Округление угла до ближайшего кратного 90 градусов
    if (Ang >= 315) or (Ang < 45) then
        Result := 0
    else if (Ang >= 45) and (Ang < 135) then
        Result := 90
    else if (Ang >= 135) and (Ang < 225) then
        Result := 180
    else
        Result := 270;
end;

procedure ProcessText(AText: IPCB_Text;
                      TopRotList, BotRotList, TopMirList, BotMirList: TStringList);
var
    VisualAngle: Integer;
    LabelText: String;
begin
    if AText = nil then Exit;

    // Only Designator texts are checked
    if not AText.IsDesignator then Exit;

    // Skip hidden (Hide) designators
    if AText.IsHidden then Exit;

    LabelText := AText.Text;
    if LabelText = '' then Exit;

    // Angle of the text primitive itself (no component context)
    VisualAngle := NormalizeAngle(AText.Rotation);

    if AText.Layer = eTopOverlay then
    begin
        // Top Overlay bad angles: 180, 270
        if (VisualAngle = 180) or (VisualAngle = 270) then
            if TopRotList.IndexOf(LabelText) = -1 then
                TopRotList.Add(LabelText);
        // Top Overlay Mirror error: MirrorFlag = ON
        if AText.MirrorFlag then
            if TopMirList.IndexOf(LabelText) = -1 then
                TopMirList.Add(LabelText);
    end
    else if AText.Layer = eBottomOverlay then
    begin
        // Bottom Overlay: mirrored text stores inverted angle (stored 90 displays as 270)
        if AText.MirrorFlag then
            VisualAngle := (360 - VisualAngle) mod 360;
        // Bottom Overlay bad angles: 180, 270 (good: 0, 90, 360->0)
        if (VisualAngle = 180) or (VisualAngle = 270) then
            if BotRotList.IndexOf(LabelText) = -1 then
                BotRotList.Add(LabelText);
        // Bottom Overlay Mirror error: MirrorFlag = OFF
        if not AText.MirrorFlag then
            if BotMirList.IndexOf(LabelText) = -1 then
                BotMirList.Add(LabelText);
    end;
end;

procedure Main;
var
    Board: IPCB_Board;
    TextIterator: IPCB_BoardIterator;
    TextObj: IPCB_Text;

    TopOverlayBadRot: TStringList;
    BotOverlayBadRot: TStringList;
    TopOverlayBadMir: TStringList;
    BotOverlayBadMir: TStringList;

    ReportMsg: String;

    SaveDialog: TSaveDialog;
    ReportFile: TStringList;

    function FormatList(AList: TStringList): String;
    var
        i: Integer;
    begin
        if AList.Count = 0 then
            Result := 'none'
        else
        begin
            Result := '';
            for i := 0 to AList.Count - 1 do
            begin
                if i > 0 then Result := Result + ', ';
                Result := Result + AList[i];
            end;
        end;
    end;

begin
    Board := PCBServer.GetCurrentPCBBoard;
    if Board = nil then
    begin
        ShowError('Open a PCB document (*.PcbDoc) via the Files or Projects menu.');
        Exit;
    end;

    TopOverlayBadRot := TStringList.Create;
    BotOverlayBadRot := TStringList.Create;
    TopOverlayBadMir := TStringList.Create;
    BotOverlayBadMir := TStringList.Create;

    try
        // Iterate text primitives on overlay layers only (no component context)
        TextIterator := Board.BoardIterator_Create;
        TextIterator.AddFilter_ObjectSet(MkSet(eTextObject));
        TextIterator.AddFilter_LayerSet(MkSet(eTopOverlay, eBottomOverlay));
        TextIterator.AddFilter_Method(eProcessAll);

        TextObj := TextIterator.FirstPCBObject;
        while TextObj <> nil do
        begin
            ProcessText(TextObj,
                        TopOverlayBadRot, BotOverlayBadRot,
                        TopOverlayBadMir, BotOverlayBadMir);
            TextObj := TextIterator.NextPCBObject;
        end;
        Board.BoardIterator_Destroy(TextIterator);

        // Формирование и вывод итогового отчета
        ReportMsg := '=== SILKSCREEN DESIGNATOR ANALYSIS RESULTS ===' + #13#10 + #13#10;

        ReportMsg := ReportMsg + '1. Components with invalid rotation angle:' + #13#10;
        ReportMsg := ReportMsg + 'Top Overlay (180°, 270°): ' + FormatList(TopOverlayBadRot) + #13#10;
        ReportMsg := ReportMsg + 'Bottom Overlay (180°, 270°): ' + FormatList(BotOverlayBadRot) + #13#10 + #13#10;

        ReportMsg := ReportMsg + '2. Components with incorrect Mirror parameter:' + #13#10;
        ReportMsg := ReportMsg + 'Top Overlay (Mirror = ON): ' + FormatList(TopOverlayBadMir) + #13#10;
        ReportMsg := ReportMsg + 'Bottom Overlay (Mirror = OFF): ' + FormatList(BotOverlayBadMir);

        ShowMessage(ReportMsg);

        // Ask to save the report to a txt file
        if MessageDlg('Save the error report to a txt file?', mtConfirmation, mbYesNo, 0) = mrYes then
        begin
            SaveDialog := TSaveDialog.Create(nil);
            try
                SaveDialog.Title := 'Save report';
                SaveDialog.Filter := 'Text files (*.txt)|*.txt|All files (*.*)|*.*';
                SaveDialog.DefaultExt := 'txt';
                SaveDialog.FileName := 'CheckOverlayDesignators_Report.txt';
                if SaveDialog.Execute then
                begin
                    ReportFile := TStringList.Create;
                    try
                        ReportFile.Text := ReportMsg;
                        ReportFile.SaveToFile(SaveDialog.FileName);
                        ShowInfo('Report saved: ' + SaveDialog.FileName);
                    finally
                        ReportFile.Free;
                    end;
                end;
            finally
                SaveDialog.Free;
            end;
        end;

    finally
        TopOverlayBadRot.Free;
        BotOverlayBadRot.Free;
        TopOverlayBadMir.Free;
        BotOverlayBadMir.Free;
    end;
end;